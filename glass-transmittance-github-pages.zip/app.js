const video = document.getElementById("video");
const canvas = document.getElementById("canvas");
const ctx = canvas.getContext("2d", { willReadFrequently: true });

const $ = (id) => document.getElementById(id);
const startBtn = $("startBtn");
const baselineBtn = $("baselineBtn");
const glassBtn = $("glassBtn");
const resetBtn = $("resetBtn");

let stream = null;
let track = null;
let rafId = null;
let liveSamples = [];
let baseline = null;
let glassMeasurements = [];
let exposureLocked = false;

function setMessage(text, className = "") {
  const el = $("message");
  el.textContent = text;
  el.className = className;
}

function median(values) {
  const sorted = [...values].sort((a, b) => a - b);
  const m = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[m] : (sorted[m - 1] + sorted[m]) / 2;
}

function stddev(values) {
  if (values.length < 2) return 0;
  const mean = values.reduce((a, b) => a + b, 0) / values.length;
  return Math.sqrt(values.reduce((s, v) => s + (v - mean) ** 2, 0) / values.length);
}

function linearize(v) {
  v /= 255;
  return v <= 0.04045 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4;
}

function readCenterLuminance() {
  if (!video.videoWidth || !video.videoHeight) return null;

  const sampleSize = 160;
  canvas.width = sampleSize;
  canvas.height = sampleSize;

  const sourceSize = Math.min(video.videoWidth, video.videoHeight) * 0.42;
  const sx = (video.videoWidth - sourceSize) / 2;
  const sy = (video.videoHeight - sourceSize) / 2;

  ctx.drawImage(video, sx, sy, sourceSize, sourceSize, 0, 0, sampleSize, sampleSize);
  const data = ctx.getImageData(0, 0, sampleSize, sampleSize).data;

  const luminances = [];
  let clipped = 0;
  for (let i = 0; i < data.length; i += 16) {
    const r = data[i], g = data[i + 1], b = data[i + 2];
    if (r > 250 || g > 250 || b > 250) clipped++;
    const y = 0.2126 * linearize(r) + 0.7152 * linearize(g) + 0.0722 * linearize(b);
    luminances.push(y);
  }

  return {
    value: median(luminances),
    clippedRatio: clipped / luminances.length
  };
}

function updateLive() {
  const reading = readCenterLuminance();
  if (reading) {
    liveSamples.push(reading.value);
    if (liveSamples.length > 45) liveSamples.shift();

    const value = median(liveSamples);
    const variation = value > 0 ? stddev(liveSamples) / value * 100 : 999;

    $("liveLuma").textContent = value.toFixed(4);
    $("stability").textContent =
      liveSamples.length < 20 ? "采集中" :
      variation < 1.5 ? "稳定" :
      variation < 4 ? "一般" : "不稳定";

    $("stability").className =
      variation < 1.5 ? "good" :
      variation < 4 ? "warn" : "bad";

    if (reading.clippedRatio > 0.05) {
      setMessage("画面可能过曝，请对准较暗且均匀的目标，避免灯泡或太阳直射。", "warn");
    }
  }
  rafId = requestAnimationFrame(updateLive);
}

async function tryLockCamera() {
  if (!track) return;
  const caps = track.getCapabilities ? track.getCapabilities() : {};
  const settings = track.getSettings ? track.getSettings() : {};
  const advanced = {};

  if (caps.focusMode?.includes("continuous")) advanced.focusMode = "continuous";
  if (caps.whiteBalanceMode?.includes("manual")) advanced.whiteBalanceMode = "manual";

  // 部分Android浏览器支持，iOS Safari通常不会公开这些控制。
  if (caps.exposureMode?.includes("manual")) {
    advanced.exposureMode = "manual";
    if (typeof settings.exposureTime === "number") advanced.exposureTime = settings.exposureTime;
  } else if (caps.exposureMode?.includes("continuous")) {
    advanced.exposureMode = "continuous";
  }

  try {
    if (Object.keys(advanced).length) {
      await track.applyConstraints({ advanced: [advanced] });
      exposureLocked = advanced.exposureMode === "manual";
    }
  } catch (err) {
    console.warn("无法应用摄像头高级约束:", err);
  }
}

async function startCamera() {
  try {
    stream = await navigator.mediaDevices.getUserMedia({
      audio: false,
      video: {
        facingMode: { ideal: "environment" },
        width: { ideal: 1920 },
        height: { ideal: 1080 }
      }
    });

    video.srcObject = stream;
    await video.play();
    track = stream.getVideoTracks()[0];
    await tryLockCamera();

    $("cameraPlaceholder").style.display = "none";
    $("cameraInfo").textContent = exposureLocked ? "曝光已锁" : "自动曝光";
    startBtn.disabled = true;
    baselineBtn.disabled = false;
    glassBtn.disabled = true;
    liveSamples = [];
    updateLive();

    setMessage("请先固定手机，对准均匀目标。等待“稳定程度”显示稳定后进行无玻璃校准。");
  } catch (err) {
    console.error(err);
    const insecure = !window.isSecureContext;
    setMessage(
      insecure
        ? "摄像头被浏览器阻止：请使用 HTTPS 地址，或在运行服务器的设备上打开 localhost。"
        : `无法启动摄像头：${err.message || err}`,
      "bad"
    );
  }
}

async function collectStableMeasurement(seconds = 2.5) {
  const values = [];
  const clipped = [];
  const start = performance.now();

  while (performance.now() - start < seconds * 1000) {
    const r = readCenterLuminance();
    if (r) {
      values.push(r.value);
      clipped.push(r.clippedRatio);
    }
    await new Promise(resolve => setTimeout(resolve, 50));
  }

  if (values.length < 20) throw new Error("有效画面不足");
  const value = median(values);
  const variation = value > 0 ? stddev(values) / value * 100 : 999;
  const clippedRatio = median(clipped);

  if (variation > 4) throw new Error("画面变化太大，请固定手机和目标后重试");
  if (clippedRatio > 0.05) throw new Error("画面过曝，请避开太阳或灯泡直射");

  return { value, variation };
}

async function calibrateBaseline() {
  baselineBtn.disabled = true;
  glassBtn.disabled = true;
  setMessage("正在记录无玻璃基准，请不要移动手机……");

  try {
    liveSamples = [];
    await new Promise(r => setTimeout(r, 1200));
    baseline = await collectStableMeasurement();
    $("baselineValue").textContent = baseline.value.toFixed(4);
    glassBtn.disabled = false;
    setMessage("基准完成。保持手机和目标完全不动，只把玻璃升起或放到镜头与目标之间。");
  } catch (err) {
    baselineBtn.disabled = false;
    setMessage(err.message, "bad");
  }
}

async function measureGlass() {
  glassBtn.disabled = true;
  baselineBtn.disabled = true;
  setMessage("正在记录隔玻璃亮度，请不要移动手机……");

  try {
    liveSamples = [];
    await new Promise(r => setTimeout(r, 1200));
    const measurement = await collectStableMeasurement();
    glassMeasurements.push(measurement.value);

    const glassValue = median(glassMeasurements);
    const rawRatio = baseline.value > 0 ? glassValue / baseline.value : 0;
    const percent = Math.max(0, Math.min(120, rawRatio * 100));
    const repeatError = glassMeasurements.length > 1
      ? stddev(glassMeasurements) / glassValue * 100
      : null;

    $("glassValue").textContent = glassValue.toFixed(4);
    $("result").textContent = `${percent.toFixed(1)}%`;
    $("errorValue").textContent = repeatError === null ? "再测一次" : `±${repeatError.toFixed(1)}%`;

    const resultEl = $("result");
    resultEl.className = percent >= 75 ? "good" : percent >= 67 ? "warn" : "bad";

    if (percent > 105) {
      setMessage("结果超过100%，说明自动曝光或环境光发生了变化。本次数据无效，请重新校准。", "bad");
    } else if (percent >= 67 && percent <= 73) {
      setMessage("结果接近70%边界。手机自动曝光和环境变化可能造成误差，必须用专业仪器确认。", "warn");
    } else {
      setMessage(`第${glassMeasurements.length}次测量完成。可保持位置不动再次测量，程序会取中位数。`);
    }

    glassBtn.disabled = false;
  } catch (err) {
    glassBtn.disabled = false;
    setMessage(err.message, "bad");
  }
}

function resetAll() {
  baseline = null;
  glassMeasurements = [];
  liveSamples = [];
  $("baselineValue").textContent = "--";
  $("glassValue").textContent = "--";
  $("result").textContent = "--%";
  $("result").className = "";
  $("errorValue").textContent = "--";
  baselineBtn.disabled = !stream;
  glassBtn.disabled = true;
  setMessage(stream ? "已清除数据，请重新进行无玻璃校准。" : "请先启动摄像头。");
}

startBtn.addEventListener("click", startCamera);
baselineBtn.addEventListener("click", calibrateBaseline);
glassBtn.addEventListener("click", measureGlass);
resetBtn.addEventListener("click", resetAll);

window.addEventListener("beforeunload", () => {
  if (rafId) cancelAnimationFrame(rafId);
  if (stream) stream.getTracks().forEach(t => t.stop());
});

if (!navigator.mediaDevices?.getUserMedia) {
  setMessage("当前浏览器不支持摄像头网页接口。请使用最新版 Safari、Chrome 或 Edge。", "bad");
}
