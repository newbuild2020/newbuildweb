# Glass Transmittance Tester

手机摄像头玻璃透光率估算工具。

## GitHub Pages 部署

1. 新建 GitHub 仓库，例如 `glass-transmittance-tester`
2. 上传本目录全部文件到仓库根目录
3. 打开 `Settings` → `Pages`
4. `Source` 选择 `Deploy from a branch`
5. Branch 选择 `main`，目录选择 `/ (root)`
6. 保存后访问：
   `https://你的GitHub用户名.github.io/glass-transmittance-tester/`

> 本工具仅供相对估算，不能代替专业透过率计。
